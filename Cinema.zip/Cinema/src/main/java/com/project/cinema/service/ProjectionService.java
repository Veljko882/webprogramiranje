package com.project.cinema.service;

import com.project.cinema.model.Projection;
import com.project.cinema.model.Reservation;
import com.project.cinema.repository.ProjectionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProjectionService {

    @Autowired
    private ProjectionRepository projectionRepository;

    public void save(Projection projection){
        //TODO
    }

    public void delete(Long id){
        //TODO
    }

    public void update(Projection projection){
        //TODO
    }

    public List<Reservation> reservations(Long id){
        //TODO
        return null;
    }

    public Projection findById(Long id){
        //TODO
        return null;
    }
}
