package com.project.cinema.controller;

import com.project.cinema.model.Projection;
import com.project.cinema.service.ProjectionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/projection")
public class ProjectionController {

    @Autowired
    private ProjectionService projectionService;

    @RequestMapping( method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> create(@RequestBody Projection projection, @RequestParam(value = "movie_id") Long movieId, @RequestParam(value = "hall_id") Long hall_id){
        projectionService.save(projection);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @RequestMapping( method = RequestMethod.DELETE)
    public ResponseEntity<?> delete(@RequestParam(value = "id") Long id){
        projectionService.delete(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @RequestMapping( method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> update(@RequestBody Projection projection){
        projectionService.update(projection);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @RequestMapping( method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Projection> findById(@RequestParam(value = "id") Long id){
        return new ResponseEntity<>(projectionService.findById(id),HttpStatus.OK);
    }

    @RequestMapping( value = "/reservations", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> reservations(@RequestParam(value = "id") Long id){
        projectionService.reservations(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
