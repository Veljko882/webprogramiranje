package com.project.cinema.controller;

import com.project.cinema.service.ReservationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/reservation")
public class ReservationController {

    @Autowired
    private ReservationService reservationService;

    @RequestMapping(method = RequestMethod.POST)
    public ResponseEntity<?> create(@RequestParam(value = "projection_id") Long projectionId, @RequestParam(value = "num_od_cards") Integer numOfCards){
        reservationService.create(projectionId, numOfCards);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.PUT)
    public ResponseEntity<?> confirm(@RequestParam(value = "id") Long id){
        reservationService.confirm(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @RequestMapping( method = RequestMethod.DELETE)
    public ResponseEntity<?> cancel(@RequestParam(value = "reservation_id") Long reservationId){
        reservationService.cancel(reservationId);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
