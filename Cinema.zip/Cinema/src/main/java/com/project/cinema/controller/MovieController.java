package com.project.cinema.controller;

import com.project.cinema.model.Cinema;
import com.project.cinema.model.Movie;
import com.project.cinema.model.Projection;
import com.project.cinema.model.Reservation;
import com.project.cinema.service.CinemaService;
import com.project.cinema.service.MovieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/movie")
public class MovieController {

    @Autowired
    private MovieService movieService;

    @RequestMapping( method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> create(@RequestBody Movie movie){
        movieService.save(movie);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @RequestMapping( method = RequestMethod.DELETE)
    public ResponseEntity<?> delete(@RequestParam(value = "id") Long id){
        movieService.delete(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @RequestMapping( method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> update(@RequestBody Movie movie){
        movieService.update(movie);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @RequestMapping( method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Movie> findById(@RequestParam(value = "id") Long id){
        return new ResponseEntity<>(movieService.findById(id),HttpStatus.OK);
    }

    @RequestMapping(value = "/projections", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Projection>> projections(@RequestParam(value = "id") Long id) {
        return new ResponseEntity<>(movieService.projections(id), HttpStatus.OK);
    }

    @RequestMapping(value = "/search", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Movie>> search(@RequestParam(value = "name") String name, @RequestParam(value = "genre") String genre, @RequestParam(value = "description") String description,
                                              @RequestParam(value = "rate") Float rate, @RequestParam(value = "price") Double price, @RequestParam(value = "time") Date time) {
        return new ResponseEntity<>(movieService.search(name,genre,description,rate,price,time), HttpStatus.OK);
    }

}
