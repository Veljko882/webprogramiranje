package com.project.cinema.service;

import com.project.cinema.model.Rate;
import com.project.cinema.repository.RateRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RateService {

    @Autowired
    private RateRepository rateRepository;

    public void rate(Long movieId, Double value){
        //TODO
    }
}
