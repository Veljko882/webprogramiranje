package com.project.cinema.service;

import com.project.cinema.model.Cinema;
import com.project.cinema.model.Movie;
import com.project.cinema.model.Rate;
import com.project.cinema.model.User;
import com.project.cinema.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public void signUp(User user){
        //TODO
    }

    public User getCurrentUser(){
        //TODO
        return null;
    }

    public void update(User user){
        //TODO
    }

    public List<Movie> watchedMovies(){
        //TODO
        return null;
    }

    public List<Movie> watchedMovies(Boolean rated){
        //TODO
        return null;
    }

    public List<Movie> reservedMovies(){
        //TODO
        return null;
    }

    public List<Rate> rates(){
        //TODO
        return null;
    }

    public void enableUser(Long id){
        //TODO
    }

    public List<Cinema> myCinemas(){
        //TODO
        return null;
    }

    public void delete(Long id){
        //TODO
    }

}
