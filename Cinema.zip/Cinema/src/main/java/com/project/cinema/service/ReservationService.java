package com.project.cinema.service;

import org.springframework.stereotype.Service;

@Service
public class ReservationService {

    public void create(Long projectionId, Integer numOfCards){
        //TODO
    }

    public void confirm(Long id){
        //TODO
    }

    public void cancel(Long reservationId){
        //TODO
    }
}
