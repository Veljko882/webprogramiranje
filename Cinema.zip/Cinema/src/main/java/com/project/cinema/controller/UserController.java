package com.project.cinema.controller;

import com.project.cinema.model.Cinema;
import com.project.cinema.model.User;
import com.project.cinema.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    @RequestMapping( method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> signUp(@RequestBody User user){
        userService.signUp(user);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @RequestMapping( method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> update(@RequestBody User user){
        userService.update(user);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @RequestMapping( method = RequestMethod.DELETE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> delete(@RequestParam(value = "id") Long id){
        userService.delete(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @RequestMapping( value = "/current_user", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getCurrentUser(){
        return new ResponseEntity<>(userService.getCurrentUser(),HttpStatus.OK);
    }

    @RequestMapping( value = "/watched_movies", method = RequestMethod.GET, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> watchedMovies(){
        return new ResponseEntity<>(userService.watchedMovies(),HttpStatus.OK);
    }

    @RequestMapping( value = "/watched_movies_r", method = RequestMethod.GET, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> watchedMovies(@RequestParam(value = "rated") Boolean rated){
        return new ResponseEntity<>(userService.watchedMovies(rated),HttpStatus.OK);
    }

    @RequestMapping( value = "/reserved_movies", method = RequestMethod.GET, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> reservedMovies(){
        return new ResponseEntity<>(userService.reservedMovies(),HttpStatus.OK);
    }

    @RequestMapping( value = "/rates", method = RequestMethod.GET, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> rates(){
        return new ResponseEntity<>(userService.rates(),HttpStatus.OK);
    }

    @RequestMapping( value = "/my_cinemas", method = RequestMethod.GET, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Cinema>> myCinemas(){
        return new ResponseEntity<>(userService.myCinemas(),HttpStatus.OK);
    }

    @RequestMapping( value = "/enable", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> enable(@RequestParam(value = "id") Long userId){
        userService.enableUser(userId);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
