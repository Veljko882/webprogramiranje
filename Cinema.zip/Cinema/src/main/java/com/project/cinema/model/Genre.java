package com.project.cinema.model;

public enum Genre {
    ACTION,
    COMEDY
}
