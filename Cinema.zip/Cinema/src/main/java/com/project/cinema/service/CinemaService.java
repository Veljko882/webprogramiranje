package com.project.cinema.service;

import com.project.cinema.model.Cinema;
import com.project.cinema.model.Hall;
import com.project.cinema.repository.CinemaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CinemaService {

    @Autowired
    private CinemaRepository cinemaRepository;

    public void save(Cinema cinema){
        //TODO
    }

    public void delete(Long id){
        //TODO
    }

    public void update(Cinema cinema){
        //TODO
    }

    public Cinema findById(Long id){
        //TODO
        return null;
    }

    public List<Hall> halls(Long id){
        //TODO
        return null;
    }
}
