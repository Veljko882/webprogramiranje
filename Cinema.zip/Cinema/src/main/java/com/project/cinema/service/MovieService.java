package com.project.cinema.service;

import com.project.cinema.model.Movie;
import com.project.cinema.model.Projection;
import com.project.cinema.model.Reservation;
import com.project.cinema.repository.MovieRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class MovieService {

    @Autowired
    private MovieRepository movieRepository;

    public void save(Movie movie){
        //TODO
    }

    public void delete(Long id){
        //TODO
    }

    public void update(Movie movie){
        //TODO
    }

    public Movie findById(Long id){
        //TODO
        return null;
    }

    public List<Projection> projections(Long id){
        //TODO
        return null;
    }

    public List<Movie> search(String name, String genre, String descrption, Float rate, Double price, Date time){
        //TODO
        return null;
    }
}
