package com.project.cinema.service;

import com.project.cinema.model.Hall;
import com.project.cinema.model.Projection;
import com.project.cinema.repository.HallRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class HallService {

    @Autowired
    private HallRepository hallRepository;

    public void save(Hall hall){
        //TODO
    }

    public void delete(Long id){
        //TODO
    }

    public void update(Hall hall){
        //TODO
    }

    public Hall findById(Long id){
        //TODO
        return null;
    }

    public List<Projection> projections(Long id, Date fromDate, Date endDate){
        //TODO
        return null;
    }
}
