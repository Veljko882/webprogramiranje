import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {SignInComponent} from './sign-in/sign-in.component';
import {RegistrationComponent} from './registration/registration.component';
import {AddCinemaComponent} from './add-cinema/add-cinema.component';
import {ProfileComponent} from './profile/profile.component';


const routes: Routes = [
  {path: 'login', component: SignInComponent},
  {path: 'registration', component: RegistrationComponent},
  {path: 'add-cinema', component: AddCinemaComponent},
  {path: 'profile', component: ProfileComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
